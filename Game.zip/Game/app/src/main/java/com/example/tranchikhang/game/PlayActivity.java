package com.example.tranchikhang.game;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Random;

public class PlayActivity extends Activity implements  Handler.Callback{
    private final String[] pheptinhs = {"+","-"};
    private ImageButton Start;
    private TextView Score;
    private int IScore = 0;
    private TextView Question;
    private ProgressBar progressBar;
    private int second = 0;
    private boolean Ready = false;
    private int Tf = 0;
    Object obj = new Object();
    private Handler MainHandler;
    private Handler CountTimeHandler;
    private HandlerThread handlerThread;
    public static final int COUNTDOWN = 2;
    public static final int END = 3;
    public static final int GENERRATE = 5;
    public static final int UPDATEPROGRESSBAR = 6;
    public static final int SHOWQUESTION = 9;
    public static final int SHOWSTART = 10;
    public static final int PAUSE = 11;
    public static final int RESTART = 12;
    public static final int SETTIME = 13;
    private  int MAXTIME = 3000;
    private  int SEGMENT = 100;
    private  int NumberRange = 100;
    private boolean Pause = true;
    private boolean Running = false;
    private String Squestion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);
        // set up View Components
        Start = (ImageButton) findViewById(R.id.Start);
        Score = (TextView) findViewById(R.id.Score);
        Question = (TextView) findViewById(R.id.PhepTinh);
        // set up Progressbar Time
        progressBar = (ProgressBar) findViewById(R.id.ProTime);
        //set up  values
        if(savedInstanceState!=null) {
            Running = savedInstanceState.getBoolean("running");
            IScore = savedInstanceState.getInt("score");
            Pause = savedInstanceState.getBoolean("pause");
            MAXTIME = savedInstanceState.getInt("maxtime");
            SEGMENT = savedInstanceState.getInt("segment");
            NumberRange = savedInstanceState.getInt("numberRange");
            Squestion = savedInstanceState.getString("question");
            Tf = savedInstanceState.getInt("tf");
            Ready = savedInstanceState.getBoolean("ready");
            second = savedInstanceState.getInt("second");
            Question.setText(Squestion);
            Score.setText(String.valueOf(IScore));
        }
        else {
            Pause = true;
            Running = false;
            Intent intent = this.getIntent();
            MAXTIME = intent.getIntExtra("maxtime",3000);
            SEGMENT = intent.getIntExtra("segment",100);
            NumberRange = intent.getIntExtra("range",100);
        }
        // create background thread and start
        handlerThread = new HandlerThread("COUNTTIME", Process.THREAD_PRIORITY_BACKGROUND);
        handlerThread.start();
        // associate CountTimeHander with BackGround thread
        CountTimeHandler = new Handler(handlerThread.getLooper(),this);
        // associate MainHandler with Main Thread
        MainHandler = new Handler(Looper.getMainLooper(),this);
        progressBar.setMax(MAXTIME);
        progressBar.setProgress(MAXTIME);
    }

    @Override
    protected void onResume() {
        super.onResume();
        CountTimeHandler.sendEmptyMessage(RESTART);
        if(Running)
            CountTimeHandler.sendEmptyMessage(GENERRATE);
    }

    protected void onPause() {
        super.onPause();
        // dung luong
        CountTimeHandler.sendEmptyMessage(PAUSE);
    }

    @Override
    protected void onSaveInstanceState(Bundle save) {
        super.onSaveInstanceState(save);
        save.putInt("score",IScore);
        save.putBoolean("pause",Pause);
        save.putInt("maxtime",MAXTIME);
        save.putInt("segment",SEGMENT);
        save.putInt("numberRange",NumberRange);
        save.putString("question",Squestion);
        save.putInt("tf",Tf);
        save.putBoolean("ready",Ready);
        save.putInt("second",second);
        save.putBoolean("running",Running);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handlerThread.quitSafely();
    }

    public  void onCheck(View view) {
        if (Ready) {
            Ready = false;
            if (view.getId() == R.id.True) {
                if (Tf == 1) {
                    CountTimeHandler.sendEmptyMessage(SETTIME);
                    CountTimeHandler.sendEmptyMessage(GENERRATE);
                } else CountTimeHandler.sendEmptyMessage(END);
            } else {
                if (Tf == 0) {
                    CountTimeHandler.sendEmptyMessage(SETTIME);
                    CountTimeHandler.sendEmptyMessage(GENERRATE);
                } else CountTimeHandler.sendEmptyMessage(END);
            }
        }
    }

    public void onStartAgain(View view) {
        IScore = -1;
        Score.setText("0");
        Running = true;
        second = 0;
        Start.setVisibility(View.INVISIBLE);
        CountTimeHandler.sendEmptyMessage(RESTART);
        CountTimeHandler.sendEmptyMessage(GENERRATE);
    }

    public void taoPhepTinh() {
        Random random = new Random();
        int a = random.nextInt(NumberRange);
        int b = random.nextInt(NumberRange);
        int pt = random.nextInt(2);
        int result = random.nextInt(2*NumberRange);
        int tf = random.nextInt(2);
        int trueTresult = 0;
        if(pt==0) {
            if(result==a+b) tf = 1;
            trueTresult = a+b;
        }
        else {
            if(result==a-b) tf=1;
            trueTresult = a-b;
        }
        StringBuilder show = new StringBuilder();
        show.append(String.valueOf(a));
        show.append(" ");
        show.append(pheptinhs[pt]);
        show.append(" ");
        show.append(String.valueOf(b));
        show.append(" = ");
        if(tf==1) {
            result = trueTresult;
        }
        show.append(String.valueOf(result));
        Squestion = show.toString();
        this.Tf = tf;
    }

    @Override
    public boolean handleMessage(Message message) {
        switch(message.what) {
            case COUNTDOWN:
                if (second > 0 && !Pause) {
                    second -= SEGMENT;
                    Message msg = MainHandler.obtainMessage(UPDATEPROGRESSBAR);
                    msg.arg1 = second;
                    MainHandler.sendMessage(msg);
                    CountTimeHandler.sendEmptyMessageDelayed(COUNTDOWN, SEGMENT);
                } else {
                    CountTimeHandler.removeMessages(COUNTDOWN);
                    if(second<=0) CountTimeHandler.sendEmptyMessage(END);
                }
                break;
            case END:
                second = 0;
                Running = false;
                Pause = true;
                MainHandler.sendEmptyMessage(SHOWSTART);
                break;
            case GENERRATE:
                if(second==0) {
                    second = MAXTIME;
                    CountTimeHandler.removeMessages(COUNTDOWN);
                    taoPhepTinh();
                    MainHandler.sendEmptyMessage(SHOWQUESTION);
                }
                CountTimeHandler.sendEmptyMessage(COUNTDOWN);
                break;
            case UPDATEPROGRESSBAR:
                int current = message.arg1;
                progressBar.setProgress(current);
                break;
            case SHOWQUESTION:
                IScore++;
                Score.setText(String.valueOf(IScore));
                Question.setText(Squestion);
                Ready = true;
                break;
            case SHOWSTART:
                Start.setVisibility(View.VISIBLE);
                break;
            case PAUSE:
                Pause = true;
                break;
            case RESTART:
                Pause = false;
                break;
            case SETTIME:
                second = 0;
                break;
            default:
                break;
        }
        return true;
    }
}
