package com.example.tranchikhang.game;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends Activity {

   private  EditText MyRange;
   private  EditText Time;
    private EditText segment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MyRange = (EditText) findViewById(R.id.Range);
        Time = (EditText) findViewById(R.id.Time);
        segment = (EditText) findViewById(R.id.segment);
    }
    public void onPlay(View view){
        String Ssegment = segment.getText().toString();
        String Srange = MyRange.getText().toString();
        String STime = Time.getText().toString();
        Intent send = new Intent(this,PlayActivity.class);
        if(!Ssegment.isEmpty()) send.putExtra("segment",Integer.valueOf(Ssegment));
        else send.putExtra("segment",100);

        if(!Srange.isEmpty()) send.putExtra("range",Integer.valueOf(Srange));
        else send.putExtra("range",100);

        if(!STime.isEmpty()) send.putExtra("maxtime",Integer.valueOf(STime));
        else send.putExtra("maxtime",3000);
        startActivity(send);
    }
}
